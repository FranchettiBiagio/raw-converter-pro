#!/bin/bash
# Franchetti Raw Converter Pro 2.58.2 — avvio assistito su macOS
# Prepara l'ambiente dentro questa cartella e apre il programma.
# Non installa nulla fuori dalla cartella e dalla cartella dati dell'utente.

set -u
cd "$(dirname "$0")" || exit 1

VERSIONE="2.58.2"
CARTELLA_DATI="$HOME/Library/Application Support/FranchettiRawConverterPro"

pausa() {
  echo
  read -r -p "Premi Invio per chiudere questa finestra..." _
}

errore() {
  echo
  echo "PROBLEMA: $1"
  shift
  for riga in "$@"; do
    echo "  $riga"
  done
  echo
  pausa
  exit 1
}

echo "============================================================"
echo " Franchetti Raw Converter Pro $VERSIONE — macOS"
echo "============================================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
  errore "Python 3 non è installato." \
    "Installa Python 3.12 da https://www.python.org/downloads/ (include Tk)," \
    "oppure da Terminale: xcode-select --install" \
    "Poi rilancia questo file."
fi

if ! python3 -c "import sys" >/dev/null 2>&1; then
  errore "python3 non risponde." \
    "Se macOS chiede di installare gli strumenti da riga di comando, accetta e riprova."
fi

VERSIONE_PY=$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')
echo "Python trovato: $VERSIONE_PY"

case "$VERSIONE_PY" in
  3.11|3.12) ;;
  3.10) echo "Nota: Python 3.10 funziona, ma 3.11 o 3.12 sono consigliate." ;;
  3.13) echo "Nota: Python 3.13 non è la versione provata; se qualcosa non va, usa 3.12." ;;
  *)
    echo
    echo "ATTENZIONE: Python $VERSIONE_PY non è tra le versioni consigliate (3.11 o 3.12)."
    echo "Il programma può funzionare lo stesso, ma il batch potrebbe comportarsi male."
    echo
    ;;
esac

if ! python3 -c "import tkinter" >/dev/null 2>&1; then
  errore "Manca Tk, la libreria grafica di Python." \
    "Se hai installato Python da python.org, reinstalla includendo Tcl/Tk." \
    "Se usi Homebrew: brew install python-tk@$VERSIONE_PY" \
    "Poi rilancia questo file."
fi

echo "Tk: presente"

# Ambiente virtuale: nella cartella se è scrivibile, altrimenti nella cartella dati.
VENV="$(pwd)/.venv"
if [ ! -x "$VENV/bin/python" ]; then
  echo
  echo "Preparo l'ambiente (una volta sola)..."
  if ! python3 -m venv "$VENV" >/dev/null 2>&1; then
    mkdir -p "$CARTELLA_DATI" 2>/dev/null || true
    VENV="$CARTELLA_DATI/venv"
    echo "La cartella non è scrivibile: uso $VENV"
    if [ ! -x "$VENV/bin/python" ]; then
      python3 -m venv "$VENV" || errore "Non riesco a creare l'ambiente Python." \
        "Sposta la cartella nella tua cartella personale e riprova."
    fi
  fi
fi

# shellcheck disable=SC1091
source "$VENV/bin/activate" || errore "Non riesco ad attivare l'ambiente Python."

if ! python -c "import rawpy, PIL, numpy, customtkinter, cv2, pyftpdlib, skimage, watchdog, piexif, requests" >/dev/null 2>&1; then
  echo
  echo "Installo le dipendenze: circa 250 MB, serve internet solo adesso."
  echo "Può richiedere qualche minuto."
  echo
  python -m pip install --upgrade pip --disable-pip-version-check || true
  if ! pip install -r requirements.txt --disable-pip-version-check; then
    errore "L'installazione delle dipendenze non è riuscita." \
      "Controlla la connessione e rilancia questo file." \
      "Se l'errore parla di permessi, sposta la cartella nella tua cartella personale."
  fi
fi

echo
echo "Avvio del programma..."
echo "Log: $CARTELLA_DATI/franchetti_log.txt"
echo
python main.py
STATO=$?

if [ "$STATO" -ne 0 ]; then
  echo
  echo "Il programma si è chiuso con codice $STATO."
  echo "Apri il log per capire cosa è successo:"
  echo "  $CARTELLA_DATI/franchetti_log.txt"
  pausa
fi

exit "$STATO"

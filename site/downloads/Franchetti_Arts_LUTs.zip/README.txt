FRANCHETTI ARTS — 108 LUT PER FRANCHETTI RAW CONVERTER PRO
==========================================================

Contenuto
---------
108 LUT 3D in formato Adobe Cube (.cube), 17 x 17 x 17 punti, dominio 0-1,
spazio colore sRGB. Ogni file è indipendente e si può usare da solo.

Dodici famiglie, nove varianti ciascuna:

  01-09   Cinema          teal & orange, controluce, notturno
  10-18   Pellicola        resa pellicola, calda, fredda, sbiadita
  19-27   Vintage         fade, cartolina, super 8, istantanea
  28-36   Bianco e Nero   neutro, selenio, seppia, platino, ciano
  37-45   Neon            magenta e ciano, alto contrasto
  46-54   Naturale        resa fedele, bosco, cielo, terra, acqua
  55-63   Caldo           ora d'oro, tramonto, ambra, sabbia
  64-72   Freddo          ora blu, ghiaccio, nebbia, inverno
  73-81   Cross Process   sviluppo incrociato, verde, blu, rosso
  82-90   Bleach Bypass   desaturazione e contrasto
  91-99   Pastello        basso contrasto, neri alzati, tinte pastello
  100-108 Drammatico      ombre profonde, alto contrasto

Come si usano nel programma
---------------------------
1. Apri il pannello delle regolazioni avanzate.
2. Nella sezione CURVA TONALE E SPLIT TONING scegli il file .cube.
3. Regola l'intensità da 0 a 100% per dosare l'effetto.
4. L'anteprima mostra il risultato prima del batch.

Le LUT si applicano in memoria: il file RAW originale non viene mai modificato.
Il percorso della LUT non viene salvato nei preset, che restano file di dati
portabili e indipendenti dal computer.

Compatibilità
-------------
Il formato .cube è lo standard di fatto delle LUT 3D e viene letto da molti
programmi di fotoritocco e montaggio. Le LUT sono state generate per questa
applicazione e verificate con la sua stessa interpolazione trilineare.

Licenza
-------
Vedi LICENZA.txt. In sintesi: uso libero anche in lavori commerciali, nessuna
rivendita del pacchetto così com'è, nessuna garanzia.

Biagio Franchetti — novembre 2026
